import {Component} from '@angular/core'
import {Question} from './question.model'

const q = new Question(
    '¿como utilizo un componente?',
    'Miren, esta es mi pregunta',
    new Date(),
    'none'
);

@Component({
    selector: 'app-question-list',
    templateUrl:'./question-list.component.html',
    styleUrls:['./question-detail.css']
    
})

export class QuestionListComponent {
    question:Question[] = new Array(10).fill(q);
}
