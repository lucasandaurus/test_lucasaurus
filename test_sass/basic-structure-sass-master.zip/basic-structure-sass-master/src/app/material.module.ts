import {NgModule} from '@angular/core';


import {
  MatButtonModule,
  MatCheckboxModule,
  MatFormFieldModule,
  MatRadioModule,
  MatSelectModule,
  MatSlideToggleModule,
  MatCardModule,
  MatIconModule,
  MatToolbarModule,
  MatInputModule,
  MatListModule
} from '@angular/material';

const modules = [
    MatCheckboxModule,
    MatButtonModule,
    MatFormFieldModule,
    MatRadioModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatCardModule,
    MatIconModule,
    MatToolbarModule,
    MatInputModule,
    MatListModule
    
];

@NgModule({
    imports: modules,
    exports: modules
})
export class MaterialModule {}
