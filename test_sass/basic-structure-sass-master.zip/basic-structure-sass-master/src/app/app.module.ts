import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


//Material Angular
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MaterialModule } from './material.module';
import { MomentModule } from 'angular2-moment';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { AppComponent } from './app.component';
import 'hammerjs';

import {QuestionDetailComponent} from './question/question-detail.component'
import {AnswerFormComponent} from './answer/answer-form.component'
import {SigninScreenComponent} from './auth/signin.component'
import {SignUpScreenComponent} from './auth/signup.component'
import {QuestionListComponent} from './question/question-list.component'

@NgModule({
  declarations: [
    AppComponent,
    QuestionDetailComponent,
    AnswerFormComponent,
    SigninScreenComponent,
    SignUpScreenComponent,
    QuestionListComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MaterialModule,
    MomentModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
